package Ch8Classes.bankacct;

import java.util.Scanner;

public class BankAccountClientV1 {
    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);
        BankAccountV1[] accounts = new BankAccountV1[32767];


    }





    public static void run(Scanner scanner, BankAccountV1[] accounts){
        for (int i = 0; i < accounts.length; i++) {
            System.out.print("Would you like to create an account? (yes or no): ");
            String condition = scanner.next();

            if (condition.toLowerCase().equals("no")||condition.toLowerCase().equals("n")) {
                break;
            }
            System.out.print("online (1) or in-person (2): ");
            short mode = scanner.nextShort();
            if(mode == 1){
                System.out.print("First Name: ");
                String fName = scanner.next();

                System.out.print("Last Name: ");
                String lName = scanner.next();

                String name = fName + " " + lName;

                System.out.print("password: ");
                String pwd = scanner.next();

                System.out.print("pin (positive whole number less than 32767): ");
                short pin = scanner.nextShort();

                System.out.print("DOB Month: ");
                int BDMonth = scanner.nextInt();
                System.out.print("DOB Day: ");
                int BDDay = scanner.nextInt();
                System.out.print("DOB Year: ");
                int BDYear = scanner.nextInt();

                System.out.print("Address (separated by _ not space): ");
                String address = scanner.next();

                System.out.print("Email Address: ");
                String email = scanner.next();

                System.out.print("Social Security Number (no spaces or dashes): ");
                long ssn = scanner.nextLong();

                accounts[i] = new BankAccountV1(name, pwd, pin, BDMonth, BDDay, BDYear, address, email, ssn);
            }else if(mode == 2){

                System.out.print("Name: ");
                String name = scanner.nextLine();


                System.out.print("pin (positive whole number less than 32767): ");
                short pin = scanner.nextShort();

                System.out.print("DOB Month: ");
                int BDMonth = scanner.nextInt();
                System.out.print("DOB Day: ");
                int BDDay = scanner.nextInt();
                System.out.print("DOB Year: ");
                int BDYear = scanner.nextInt();

                System.out.print("Address (separated by _ not space): ");
                String address = scanner.next();

                System.out.print("starting balance: ");
                long initVal = scanner.nextLong();

                System.out.print("Social Security Number (no spaces or dashes): ");
                long ssn = scanner.nextLong();

                accounts[i] = new BankAccountV1(name, pin, BDMonth, BDDay, BDYear, address, initVal,  ssn);
            }else if(mode == 255){
                System.out.println(accounts[i-1].toString());
            }else{
                System.out.println("\n\nInvalid Selection\n\n");
            }
        }
    }
}
