package Ch8Classes.bankacct;


import java.security.NoSuchAlgorithmException;
import java.util.Random;

public class BankAccountV1 {
    private static final Random rand = new Random();

    private long balance, initial_value, acct_num;
    private String acct_holder, pwdHash, pinHash, email, address, socialSecurityNumHash;
    private int BDmonth, BDday, BDyear;


// online constructor
    public BankAccountV1(String acct_holder, String pwd, short pin,
                         int BDmonth, int BDday, int BDyear, String address,
                         String email, long socialSecurityNum){
        this.acct_holder = acct_holder;
        try {
            this.pwdHash = Hasher.toHexString(Hasher.getSHA(pwd));
            this.pinHash = Hasher.toHexString(Hasher.getSHA(String.valueOf(pin)));
            this.socialSecurityNumHash = Hasher.toHexString(Hasher.getSHA(String.valueOf(socialSecurityNum)));
        }catch (NoSuchAlgorithmException e) {
            System.out.println("Exception thrown for incorrect algorithm: " + e);
        }
        this.BDmonth = BDmonth;
        this.BDday = BDday;
        this.BDyear = BDyear;
        this.address = address;
        this.balance = 0;
        this.email = email;
        this.acct_num = rand.nextLong();
    }
// in person constructor
    public BankAccountV1(String acct_holder, short pin,
                         int BDmonth, int BDday, int BDyear, String address,
                         long initial_value, long socialSecurityNum){
        this.acct_holder = acct_holder;
        try {
            this.pinHash = Hasher.toHexString(Hasher.getSHA(String.valueOf(pin)));
            this.socialSecurityNumHash = Hasher.toHexString(Hasher.getSHA(String.valueOf(socialSecurityNum)));
        }catch (NoSuchAlgorithmException e) {
            System.out.println("Exception thrown for incorrect algorithm: " + e);
        }
        this.BDmonth = BDmonth;
        this.BDday = BDday;
        this.BDyear = BDyear;
        this.address = address;
        this.initial_value = initial_value;
        this.balance = initial_value;
        this.acct_num = rand.nextLong();
    }
    public void setAddress(String address){
        this.address = address;
    }
    public boolean changePin(short oldPin, short newPin){
        String newHash = "";
        if(comparePin(oldPin)){
            try {
                newHash = Hasher.toHexString(Hasher.getSHA(String.valueOf(newPin)));
            }catch (NoSuchAlgorithmException e) {
                System.out.println("Exception thrown for incorrect algorithm: " + e);
                return false;
            }
            this.pinHash = newHash;
            return true;
        }else{
            return false;
        }
    }
    public boolean comparePwd(String pwd){
        String hash = "";
        try {
            hash = Hasher.toHexString(Hasher.getSHA(pwd));
        }catch (NoSuchAlgorithmException e) {
            System.out.println("Exception thrown for incorrect algorithm: " + e);
        }
        return this.pwdHash.equals(hash);
    }
    public boolean comparePin(short pin){
        String hash = "";
        try {
            hash = Hasher.toHexString(Hasher.getSHA(String.valueOf(pin)));
        }catch (NoSuchAlgorithmException e) {
            System.out.println("Exception thrown for incorrect algorithm: " + e);
        }
        return this.pinHash.equals(hash);
    }
    public boolean compareSSN(long ssn){
        String hash = "";
        try {
            hash = Hasher.toHexString(Hasher.getSHA(String.valueOf(ssn)));
        }catch (NoSuchAlgorithmException e) {
            System.out.println("Exception thrown for incorrect algorithm: " + e);
        }
        return this.socialSecurityNumHash.equals(hash);
    }
    public double getBal(){
        return this.balance;
    }
    public boolean deposit(double amount){
        this.balance += amount;
        return true;
    }
    public boolean withdraw(double amount){
        if(this.balance - amount < 0){
            return false;
        }else {
            this.balance -= amount;
            return true;
        }
    }


}
